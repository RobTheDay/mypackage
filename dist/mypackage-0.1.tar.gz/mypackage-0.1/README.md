# mypackage

This package was created to act as an example of how to create a Python package
